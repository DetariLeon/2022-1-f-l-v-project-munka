with open("atlag.txt", "w", encoding="utf8()") as file:
    szoveg = "Eddigi számítások. \n"
    file.write(szoveg)
print("A(z) atlagok.txt file létrehozva")
input("A kilépéshez nyomjon egy [ENTER]-t")